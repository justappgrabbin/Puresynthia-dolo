#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(ROOT, 'dist');
const STAGE = path.join(DIST, 'synthia-computer');
const ARCHIVE = path.join(DIST, 'Synthia-Self-Compiling-Computer.zip');
const EXCLUDED = new Set(['dist', '.git', 'node_modules']);

function walk(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true })
    .sort((a, b) => a.name.localeCompare(b.name))
    .flatMap((entry) => {
      if (EXCLUDED.has(entry.name)) return [];
      const absolute = path.join(dir, entry.name);
      return entry.isDirectory() ? walk(absolute, base) : [path.relative(base, absolute)];
    });
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: ROOT, encoding: 'utf8', stdio: 'pipe', ...options });
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(' ')} failed\n${result.stdout || ''}${result.stderr || ''}`);
  }
  return result.stdout;
}

function verifyRegistry() {
  const registry = JSON.parse(fs.readFileSync(path.join(ROOT, 'system.registry.json'), 'utf8'));
  const ids = new Set();
  for (const process of registry.processes) {
    if (!process.id || !process.entry || !process.address || !process.capabilities?.length) {
      throw new Error(`Unregistered process: ${JSON.stringify(process)}`);
    }
    if (ids.has(process.id)) throw new Error(`Duplicate process id: ${process.id}`);
    ids.add(process.id);
    if (!fs.existsSync(path.join(ROOT, process.entry))) throw new Error(`Missing registered entry: ${process.entry}`);
  }
  return registry;
}

function copyTree(files) {
  fs.rmSync(STAGE, { recursive: true, force: true });
  fs.mkdirSync(STAGE, { recursive: true });
  for (const relative of files) {
    const target = path.join(STAGE, relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(path.join(ROOT, relative), target);
  }
}

async function build() {
  const registry = verifyRegistry();
  const testOutput = run(process.execPath, ['tests/run.mjs']);
  if (!/866 passed, 0 failed/.test(testOutput)) throw new Error('Core verification count missing');
  run(process.execPath, ['test/merged.smoke.mjs']);
  run(process.execPath, ['test/continuous-life.test.mjs']);
  run(process.execPath, ['test/organism-integrity.test.mjs']);
  run(process.execPath, ['test/self-compiler.test.mjs']);

  const files = walk(ROOT);
  copyTree(files);
  const manifest = {
    schema: 'synthia.birth.v1',
    identity: registry.identity,
    compiler: 'synthia-self-compiler.mjs',
    entry: 'computer.html',
    processCount: registry.processes.length,
    sourceCount: files.length,
    sources: files.map((name) => ({ name, sha256: sha256(path.join(ROOT, name)) })),
  };
  fs.writeFileSync(path.join(STAGE, 'birth.manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  fs.rmSync(ARCHIVE, { force: true });
  run('zip', ['-X', '-q', '-r', ARCHIVE, 'synthia-computer'], { cwd: DIST });
  const evidence = {
    status: 'VERIFIED',
    archive: path.basename(ARCHIVE),
    bytes: fs.statSync(ARCHIVE).size,
    sha256: sha256(ARCHIVE),
    tests: { core: 866, merged: 42, continuity: 'PASS', organismIntegrity: 12, selfCompiler: 'PASS' },
    registeredProcesses: registry.processes.map((process) => process.id),
  };
  fs.writeFileSync(path.join(DIST, 'BUILD-EVIDENCE.json'), `${JSON.stringify(evidence, null, 2)}\n`);
  console.log(JSON.stringify(evidence, null, 2));
}

build().catch((error) => {
  console.error(error.stack || error.message);
  process.exit(1);
});
