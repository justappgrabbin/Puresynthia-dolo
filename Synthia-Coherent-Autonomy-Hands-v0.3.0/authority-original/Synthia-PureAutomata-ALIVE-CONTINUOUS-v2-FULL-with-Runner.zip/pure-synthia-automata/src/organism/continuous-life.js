// Pure Synthia Automata — continuity bridge for the existing living organism.
// This does not replace the LivingLoop. It makes its endogenous life continuous
// across host restarts and records each lived episode at the StateSpace address
// that actually intook the action which caused it.

import { LivingLoop, verifyEpisodeChain } from './living-loop.js';
import { AnticipatoryMemory } from '../merged/mesh-memory.js';
import { stableStringify } from '../engine/derivation.js';

const DEFAULT_KEY = 'synthia:continuous-life:v1';

export class MemoryStateStore {
  constructor() { this.map = new Map(); }
  getItem(key) { return this.map.has(key) ? this.map.get(key) : null; }
  setItem(key, value) { this.map.set(key, String(value)); }
  removeItem(key) { this.map.delete(key); }
}

function parsePublicAddress(key) {
  const m = String(key || '').match(/^G(\d+)\.L(\d+)\.C(\d+)\.T(\d+)\.B(\d+)$/);
  if (!m) return null;
  return { gate:+m[1], line:+m[2], color:+m[3], tone:+m[4], base:+m[5] };
}

function encode(value) {
  if (value === null || typeof value !== 'object') return value;
  if (value instanceof Map) return { __kind:'Map', entries:[...value].map(([k,v]) => [encode(k), encode(v)]) };
  if (value instanceof Set) return { __kind:'Set', values:[...value].map(encode) };
  if (ArrayBuffer.isView(value)) return { __kind:value.constructor.name, values:[...value] };
  if (Array.isArray(value)) return value.map(encode);
  const out = {};
  for (const [k,v] of Object.entries(value)) {
    if (typeof v !== 'function') out[k] = encode(v);
  }
  return out;
}

function restoreInto(target, data) {
  if (data && data.__kind === 'Map') {
    const map = target instanceof Map ? target : new Map();
    map.clear();
    for (const [k,v] of data.entries || []) map.set(k, decode(v));
    return map;
  }
  if (data && data.__kind === 'Set') {
    const set = target instanceof Set ? target : new Set();
    set.clear();
    for (const v of data.values || []) set.add(decode(v));
    return set;
  }
  if (data && typeof data.__kind === 'string' && /Array$/.test(data.__kind) && Array.isArray(data.values)) {
    const C = globalThis[data.__kind];
    return typeof C === 'function' ? new C(data.values) : data.values.slice();
  }
  if (Array.isArray(data)) return data.map(decode);
  if (data && typeof data === 'object') {
    const out = target && typeof target === 'object' ? target : {};
    for (const [k,v] of Object.entries(data)) {
      if (k === '__kind') continue;
      out[k] = restoreInto(out[k], v);
    }
    return out;
  }
  return data;
}

function decode(value) { return restoreInto(null, value); }

export class ContinuousLife {
  constructor(engine, {
    seed = 0x5117,
    config = {},
    storage = null,
    storageKey = DEFAULT_KEY,
    heartbeatMs = 5000,
    autoRestore = true,
  } = {}) {
    if (!engine || typeof engine.call !== 'function') throw new TypeError('ContinuousLife requires SynthiaAutomata-compatible engine');
    this.engine = engine;
    this.loop = new LivingLoop(engine, { seed, config });
    this.memory = new AnticipatoryMemory();
    this.storage = storage || (typeof globalThis !== 'undefined' && globalThis.localStorage ? globalThis.localStorage : new MemoryStateStore());
    this.storageKey = storageKey;
    this.heartbeatMs = Math.max(250, Math.floor(heartbeatMs));
    this.timer = null;
    this.lastPersistedTick = 0;
    if (autoRestore) this.restore();
  }

  tick() {
    const result = this.loop.tick();
    if (!result.quiescent && result.episode) this.#rememberEpisode(result.episode);
    this.persist();
    return result;
  }

  start() {
    if (this.timer) return false;
    this.timer = setInterval(() => this.tick(), this.heartbeatMs);
    return true;
  }

  stop() {
    if (!this.timer) return false;
    clearInterval(this.timer);
    this.timer = null;
    this.persist();
    return true;
  }

  health() {
    const chain = verifyEpisodeChain(this.loop.log);
    return Object.freeze({
      alive: chain.valid,
      running: Boolean(this.timer),
      tick: this.loop.tickCount,
      episodes: this.loop.log.length,
      memoryPrecedents: this.memory.snapshot().precedents.length,
      chain,
      vitals: this.loop.getState().vitals,
    });
  }

  snapshot() {
    return {
      version: 2,
      engine: {
        runtime: encode(this.engine.runtime || {}),
        tools: [...(this.engine.tools || [])].map((tool) => ({
          id: tool.id, calls: tool.calls, lifecycle: tool.lifecycle, state: encode(tool.exportState?.()),
        })),
        intake: this.engine.intakeGate ? encode({
          history: this.engine.intakeGate.history,
          derivations: this.engine.intakeGate.derivations,
          tokenMemory: this.engine.intakeGate.tokenMemory,
          counter: this.engine.intakeGate.counter,
          ledger: this.engine.intakeGate.ledger?.snapshot?.(),
        }) : null,
        channels: this.engine.channels ? encode({ crossings:this.engine.channels.crossings(), seq:this.engine.channels._seq }) : null,
        intent: this.engine.intent ? encode({ intents:this.engine.intent.intents, gaps:this.engine.intent.gaps, proposals:this.engine.intent.proposals, intentSeq:this.engine.intent._intentSeq, gapSeq:this.engine.intent._gapSeq, proposalSeq:this.engine.intent._proposalSeq }) : null,
        detector: this.engine.detector ? encode({ emergenceLog:this.engine.detector.emergenceLog }) : null,
      },
      loop: this.loop.exportState(),
      memory: this.memory.snapshot(),
    };
  }

  persist() {
    const state = this.snapshot();
    this.storage.setItem(this.storageKey, stableStringify(state));
    this.lastPersistedTick = this.loop.tickCount;
    return state;
  }

  restore() {
    const raw = this.storage.getItem(this.storageKey);
    if (!raw) return false;
    const state = JSON.parse(raw);
    if (!state || (state.version !== 1 && state.version !== 2)) return false;
    if (state.version >= 2 && state.engine) this.#restoreEngine(state.engine);
    this.loop.importState(state.loop);
    this.memory.restore(state.memory);
    this.lastPersistedTick = this.loop.tickCount;
    return true;
  }

  clearPersisted() { this.storage.removeItem(this.storageKey); }

  #restoreEngine(saved) {
    if (saved.runtime && this.engine.runtime) {
      const restored = decode(saved.runtime);
      Object.assign(this.engine.runtime, restored);
    }
    for (const rec of (saved.tools || [])) {
      const tool = this.engine.toolsById?.get(rec.id);
      if (!tool) continue;
      tool.calls = Math.max(0, Math.floor(rec.calls || 0));
      tool.lifecycle = rec.lifecycle || 'ready';
      const current = tool.exportState?.();
      tool.ownedState = restoreInto(current, rec.state);
    }
    if (saved.intake && this.engine.intakeGate) {
      const r = decode(saved.intake);
      this.engine.intakeGate.history = r.history || [];
      this.engine.intakeGate.derivations = r.derivations || [];
      this.engine.intakeGate.tokenMemory = r.tokenMemory instanceof Set ? r.tokenMemory : new Set(r.tokenMemory || []);
      this.engine.intakeGate.counter = Math.max(0, Math.floor(r.counter || 0));
      if (r.ledger && this.engine.intakeGate.ledger) {
        for (const k of Object.keys(r.ledger)) this.engine.intakeGate.ledger[k] = r.ledger[k];
      }
    }
    if (saved.channels && this.engine.channels) {
      const r = decode(saved.channels);
      this.engine.channels._crossings.clear();
      for (const c of (r.crossings || [])) {
        this.engine.channels.recordCrossing(c.a, c.b);
        const live = this.engine.channels._crossings.get(`${c.a}~${c.b}`);
        if (live) Object.assign(live, c);
      }
      this.engine.channels._seq = Math.max(this.engine.channels._seq, Math.floor(r.seq || 0));
    }
    if (saved.intent && this.engine.intent) {
      const r = decode(saved.intent);
      this.engine.intent.intents = r.intents || [];
      this.engine.intent.gaps = r.gaps || [];
      this.engine.intent.proposals = r.proposals || [];
      this.engine.intent._intentSeq = r.intentSeq || 0;
      this.engine.intent._gapSeq = r.gapSeq || 0;
      this.engine.intent._proposalSeq = r.proposalSeq || 0;
    }
    if (saved.detector && this.engine.detector) {
      const r = decode(saved.detector);
      this.engine.detector.emergenceLog = r.emergenceLog || [];
    }
  }

  #rememberEpisode(episode) {
    const derivation = this.engine.runtime?.derivations?.find((d) => d.id === episode.derivationId);
    if (!derivation) return null;
    const intake = this.engine.intake?.history?.find((r) => r.id === derivation.intakeId);
    const address = parsePublicAddress(intake?.addressKey);
    if (!address) return null;
    return this.memory.observe(address, {
      kind: 'lived_episode',
      need: episode.need?.vital || null,
      strategy: episode.action?.strategy || null,
      accepted: episode.result?.accepted ?? null,
      emergent: episode.result?.emergent ?? false,
      consequenceScore: episode.consequence?.score ?? 0,
      derivationId: episode.derivationId,
      evidenceCount: 1,
      confidence: Math.max(0, Math.min(1, 0.5 + 0.5 * Math.max(-1, Math.min(1, episode.consequence?.score || 0)))),
    });
  }
}

export default ContinuousLife;
