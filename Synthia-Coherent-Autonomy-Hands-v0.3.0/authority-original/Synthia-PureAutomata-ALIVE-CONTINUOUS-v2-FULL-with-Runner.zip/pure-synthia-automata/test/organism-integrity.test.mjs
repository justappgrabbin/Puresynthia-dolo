import assert from 'node:assert/strict';
import { addressForArcSec, arcSecForAddress, geometryForAddress, validateAddress } from '../src/state-space/addressing.js';
import { WHEEL_ARCSECONDS } from '../src/state-space/constants.js';
import { ToolFactory } from '../src/merged/tool-factory.js';
import { ContinuousLife } from '../src/organism/continuous-life.js';
import { SynthiaAutomata } from '../src/engine/synthia.js';

let passed = 0;
const ok = (name, fn) => Promise.resolve().then(fn).then(() => { passed++; console.log('ok  ', name); });

await ok('address wheel resolves canonical 12 houses and preserves 8 trigram sectors', () => {
  const houses = new Set(), sectors = new Set();
  for (let d = 0; d < 360; d++) {
    const a = addressForArcSec(d * 3600);
    houses.add(a.house); sectors.add(a.trigramHouse);
    assert.equal(validateAddress(a).ok, true);
  }
  assert.deepEqual([...houses].sort((a,b)=>a-b), [1,2,3,4,5,6,7,8,9,10,11,12]);
  assert.deepEqual([...sectors].sort((a,b)=>a-b), [1,2,3,4,5,6,7,8]);
});

await ok('all 64 gate shapes occupy non-overlapping contiguous wheel arcs', () => {
  let prevEnd = 0;
  for (let gate = 1; gate <= 64; gate++) {
    const g = geometryForAddress({gate,line:1,color:1,tone:1,base:1});
    assert.equal(g.gateStartDeg, prevEnd);
    assert.equal(g.gateCenterDeg, g.gateStartDeg + 2.8125);
    prevEnd += 5.625;
  }
  assert.equal(prevEnd, 360);
});

await ok('address codec round-trips every gate/line/color/tone/base origin', () => {
  for (let gate=1; gate<=64; gate++) for (let line=1; line<=6; line++) for (let color=1;color<=6;color++) for (let tone=1;tone<=6;tone++) for (let base=1;base<=5;base++) {
    const src={gate,line,color,tone,base};
    const arc=arcSecForAddress(src);
    assert.ok(arc>=0 && arc<WHEEL_ARCSECONDS);
    const got=addressForArcSec(arc);
    assert.deepEqual([got.gate,got.line,got.color,got.tone,got.base],[gate,line,color,tone,base]);
  }
});

const sampleInput = [
  'seed', 0.75, [{color:3},{tone:3},{gate:14},{gate:99}], ['alpha beta','alpha gamma'],
  {x:1}, 'hello', 'signal', 'alpha beta alpha gamma'
];
for (let level=0; level<=7; level++) {
  await ok(`ToolFactory level ${level} generates and actually executes`, async () => {
    const f = new ToolFactory();
    const r = f.generate({purpose:'test tool', dimension:'Design', gate:14, level, address:{gate:14,line:3,color:3,tone:2,base:4,degree:77,minute:8,second:9,zodiac:3,house:3,trigramHouse:2}});
    assert.equal(r.status,'generated');
    assert.equal(r.tool.address.degree,77);
    assert.equal(r.tool.address.house,3);
    assert.equal(r.tool.address.trigramHouse,2);
    const out = await r.tool.execute(sampleInput[level]);
    assert.notEqual(out, undefined);
    assert.notEqual(out, null);
  });
}

await ok('continuous organism survives persist/restore with autobiographical continuity', async () => {
  const store = new Map();
  const storage = { getItem:k=>store.get(k)??null, setItem:(k,v)=>store.set(k,v), removeItem:k=>store.delete(k) };
  const e1 = new SynthiaAutomata();
  const a = new ContinuousLife(e1,{seed:0x5117,storage});
  for (let i=0;i<8;i++) await a.tick();
  const before=a.health();
  a.persist();
  const e2 = new SynthiaAutomata();
  const b = new ContinuousLife(e2,{seed:0x5117,storage});
  b.restore();
  const after=b.health();
  assert.equal(after.episodes,before.episodes);
  assert.equal(after.chain.head,before.chain.head);
  await b.tick();
  assert.ok(b.health().episodes >= after.episodes);
});

console.log(`\n[organism-integrity] ${passed} passed, 0 failed`);
