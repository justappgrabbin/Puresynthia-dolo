import assert from 'node:assert/strict';
import { SynthiaAutomata } from '../src/engine/synthia.js';
import { ContinuousLife, MemoryStateStore } from '../src/organism/continuous-life.js';

const store = new MemoryStateStore();
const config = { vitals: { sociality: { threshold: 0.05, initial: 0.9 } } };
const engine1 = new SynthiaAutomata();
const life1 = new ContinuousLife(engine1, { seed: 77, config, storage: store, autoRestore: false });
const r1 = life1.tick();
assert.equal(r1.quiescent, false, 'forced sociality need should act');
assert.equal(life1.loop.log.length, 1);
assert.equal(life1.health().alive, true);
assert.ok(life1.memory.snapshot().precedents.length >= 1, 'lived episode is StateSpace-addressed memory');
const savedTick = life1.loop.tickCount;
const savedHead = life1.loop.getState().logHead;
const savedWeights = life1.loop.getState().policyWeights;

const engine2 = new SynthiaAutomata();
const life2 = new ContinuousLife(engine2, { seed: 77, config, storage: store, autoRestore: true });
assert.equal(life2.loop.tickCount, savedTick, 'logical life resumes at same tick');
assert.equal(life2.loop.getState().logHead, savedHead, 'autobiographical identity chain resumes');
assert.deepEqual(life2.loop.getState().policyWeights, savedWeights, 'learned policy survives restart');
assert.equal(life2.memory.snapshot().precedents.length, life1.memory.snapshot().precedents.length, 'addressed lived memory survives restart');
assert.equal(life2.health().alive, true);
life2.tick();
assert.equal(life2.loop.tickCount, savedTick + 1, 'resumed organism continues rather than restarting');
console.log('continuous-life: PASS');
