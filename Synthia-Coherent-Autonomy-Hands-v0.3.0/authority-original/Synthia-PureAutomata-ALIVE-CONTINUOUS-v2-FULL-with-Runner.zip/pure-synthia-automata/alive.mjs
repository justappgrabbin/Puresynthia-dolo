import { SynthiaAutomata } from './src/engine/synthia.js';
import { ContinuousLife } from './src/organism/continuous-life.js';

const engine = new SynthiaAutomata();
const life = new ContinuousLife(engine, { heartbeatMs: 5000 });
console.log('Synthia continuity organism');
console.log(JSON.stringify(life.health(), null, 2));
console.log('Heartbeat started. Ctrl+C stops after persisting state.');
life.start();
const stop = () => { life.stop(); console.log(JSON.stringify(life.health(), null, 2)); process.exit(0); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
