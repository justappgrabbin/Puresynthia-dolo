# Synthia Alive Core — Continuity Integration

This package preserves the existing Pure Synthia Automata system and closes the continuity gap without replacing its architecture.

## Added continuity behavior

- Existing endogenous LivingLoop remains the organism controller.
- Vitals, active needs, learned policy weights, addressed gaps, episode chain, and loop cursors persist across restart.
- Lived episodes are written into AnticipatoryMemory at the actual StateSpace intake address that produced the action.
- Engine runtime counters/history, automata owned state, intake state, emergent channel state, intent/gap/proposal state, and emergence log are checkpointed and restored.
- Sovereign API now exposes organism.start(), stop(), health(), persist(), restore(), tick(), recent(), memory, and the underlying loop/life objects.
- `npm run alive` starts a 5-second heartbeat and persists on SIGINT/SIGTERM.

## Verification

- Original core suite: 866 passed, 0 failed.
- New continuity integration test: PASS.
- Existing merged smoke suite: 42 passed, 0 failed.
- Combined executed checks: 909 passed, 0 failed.

The continuity test verifies that an endogenous need produces an action, the episode is StateSpace-addressed in memory, the autobiographical hash-chain remains valid, learned policy survives restart, memory survives restart, and the logical organism resumes at the next tick rather than starting over.

## Structural integrity hardening — v2

The organism now distinguishes two previously conflated spatial perspectives:
- `house`: canonical astrological house, 1..12 (30° sectors)
- `trigramHouse`: Fu Xi/trigram spatial sector, 1..8 (45° sectors)

Neither perspective replaces the other. `geometryForAddress()` exposes both over the same wheel,
and `validateAddress()` checks canonical coordinate ranges without deleting donor-specific fields.

ToolFactory now preserves supplied fine coordinates on generated tools, and the integrity suite executes
all eight generated-tool levels rather than accepting construction alone.

Acceptance now includes morphology/topology integrity: 64 gate arcs must tile the full 360° wheel
without overlap or gaps, address origins must round-trip through arc-seconds, and organism continuity
must survive persistence/reload with its autobiographical episode chain intact.
