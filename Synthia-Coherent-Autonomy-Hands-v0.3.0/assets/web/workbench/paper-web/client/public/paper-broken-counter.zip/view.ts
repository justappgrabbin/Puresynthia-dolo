export function renderCounter(state: { count: number }) { return state.count; }
