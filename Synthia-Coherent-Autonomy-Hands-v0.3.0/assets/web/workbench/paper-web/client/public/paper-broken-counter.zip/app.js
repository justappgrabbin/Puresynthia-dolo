const app = document.querySelector('#app');
const items = [{ id: 'one', label: 'First' }, { id: 'two', label: 'Second' }];
app.innerHTML = `<h1>Broken counter</h1><button id="increment">0</button><ul>${items.map(item => `<li>${item.label}</li>`).join('')}</ul>`;
// PAPER_FAIL: deliberate fixture failure before the app can be considered runnable
throw new Error('PAPER_FAIL: deliberate fixture failure');
document.querySelector('#increment').addEventListener('click', () => console.log('increment'));
