import { renderCounter } from './view';
export const analyzedComponent = renderCounter;
export type FixtureState = { count: number };
